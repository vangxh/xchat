<?php /*a:1:{s:53:"D:\CmdTool\project\worker\xchat\view\xchat\match.html";i:1619441484;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>XChat客服-通用设置</title>
</head>
<body>
    <p>由于本页面使用jquery涉及额外样式及文件过多，故去掉，请自行实现</p>
</body>
</html>