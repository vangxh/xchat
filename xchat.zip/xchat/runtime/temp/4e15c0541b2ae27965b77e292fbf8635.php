<?php /*a:1:{s:52:"D:\CmdTool\project\worker\xchat\view\index\kefu.html";i:1620092617;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>XChat携信客服-DEMO</title>
    <link rel="stylesheet" href="/static/chat/css/base.css" />
    <style>
        body {
            position: relative;
            background-color: #aaa;
        }
    </style>
</head>
<body>
    <script src="http://chat.me/static/chat/js/xchat.js?type=kefu&uid=<?php echo htmlentities($uid); ?>"></script>
</body>
</html>