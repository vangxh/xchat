<?php /*a:0:{}*/ ?>
<script src="http://chat.me/static/chat/js/xchat.js?uid=0"></script>